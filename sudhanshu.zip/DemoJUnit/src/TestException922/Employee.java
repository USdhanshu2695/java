package TestException922;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Employee extends Exception {
	private int id;
	private String name;
	
	private Double  salary;
	private String designation;
	private String insuranceScheme;
	public int getId() {
		return id;
	}
	public Employee(int id, String name, Double salary, String designation, String insuranceScheme) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		this.insuranceScheme = insuranceScheme;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getSalary() {
			if(salary< 3000)
		{
				throw new IllegalArgumentException("Both Names Cannot be NULL");
		}
	
		
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
		
		
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	public Employee() {
		// TODO Auto-generated constructor stub
	}
}

