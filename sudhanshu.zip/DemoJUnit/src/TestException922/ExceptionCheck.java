package TestException922;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

public class ExceptionCheck {

	
	@Test (expected=IllegalArgumentException.class)
	public void testNullsInName()
		{
	
		System.out.println("from TestPerson2 testing exceptions");
		Employee per1 = new Employee();
		per1.setSalary(200.0);
		per1.getSalary();
	
		
		}
	/*@Test
	public void testGetFirstName()
	{
		System.out.println("from TestPerson2");
		ExceptionCheck per = new ExceptionCheck();
		per.setFirstName("Robert");
		assertEquals("Robert",per.getFirstName());
	
	}
	@Test
	public void testGetLastName()
	{
		System.out.println("from TestPerson3");
		ExceptionCheck per = new ExceptionCheck();
		per.setLastName("King");
		assertEquals("King",per.getLastName());
	
	}
	@Test
	public void testDisplay()
	{
		System.out.println("from TestPerson4");
		Person per = new Person("Robert","King");
		assertEquals("Person [firstName=" + per.getFirstName() + ", lastName=" + per.getLastName() + ", ]",per);
	
	}
	}*/
}