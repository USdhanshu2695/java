import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class PersonTest {

	@Test
	public void testGetFullName()
	{
		System.out.println("from TestPerson1");
		Person per = new Person("Robert","King");
		assertEquals("Robert King",per.getFullName());
	
	}
	@Test
	public void testGetFirstName()
	{
		System.out.println("from TestPerson2");
		Person per = new Person();
		per.setFirstName("Robert");
		assertEquals("Robert",per.getFirstName());
	
	}
	@Test
	public void testGetLastName()
	{
		System.out.println("from TestPerson3");
		Person per = new Person();
		per.setLastName("King");
		assertEquals("King",per.getLastName());
	
	}
	@Test
	public void testDisplay()
	{
		System.out.println("from TestPerson4");
		Person per = new Person("Robert","King");
		assertEquals("Person [firstName=" + per.getFirstName() + ", lastName=" + per.getLastName() + ", ]",per);
	
	}
	}