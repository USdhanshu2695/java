import org.junit.Assert;
import org.junit.Test;

public class DateTest {
Date d;
	public DateTest() {
		// TODO Auto-generated constructor stub
	}
	@Test
	public void testDivide1() {
		d= new Date(26 , 04, 2018);
		Assert.assertEquals(4,d.getMonth());

	}
	@Test
	public void testDivide2() {
		d= new Date(26 , 05, 2088);
		Assert.assertEquals(26,d.getDay());

	}
	@Test
	public void testDivide3() {
		d= new Date(16 , 04, 2018);
		Assert.assertEquals(2018,d.getYear());

	}
}
