package employee;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

public class EmployeeException   {

	public EmployeeException() {

		// TODO Auto-generated constructor stub
	}

	public String toString() {
		return "Salary is under 3000";
	}
	
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileOutputStream fos = null;
		ObjectOutputStream oos =null;
		 fos = new FileOutputStream("EmpObjs.obj");
		 oos = new ObjectOutputStream(fos);
		System.out.println("Enter no of Emp ");
		
		Scanner sc= new Scanner(System.in);
		int n = sc.nextInt();
		Employee e[] = new Employee[n];
		for(int i = 0;i<n;i++) {
		 e[i] =  new Employee();
		 System.out.println("Enter Emp name");
		 String enm = sc.next();
		 e[i].setName(enm);
		 System.out.println("Enter Emp id");
		 int eid = sc.nextInt();
		 e[i].setId(eid);
		
		 try
			{
			
			 oos.writeObject(e[i]);
			}
		
		 catch (IOException f) {
			
			f.printStackTrace();
		}

		 System.out.println("EMp e1 is written in the file");
	}
		FileInputStream fis=  null;
		ObjectInputStream ois =null;
	try 
	{
		 fis = new FileInputStream("EmpObjs.obj");
		 ois = new ObjectInputStream(fis);
		 for(int i=0;i<n;i++) {
		 Employee ee = (Employee)ois.readObject();
		 System.out.println
		 ("Emp from file :"+ ee);
	}
	}
	catch (ClassNotFoundException | IOException ee)// muti catch java 1.7 feature
	{
		
		ee.printStackTrace();
	}

	}


	}
