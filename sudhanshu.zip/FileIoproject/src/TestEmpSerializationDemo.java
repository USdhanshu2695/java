import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class TestEmpSerializationDemo {

	public TestEmpSerializationDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc= new Scanner(System.in);


System.out.println("Enter Emp id");
int eid = sc.nextInt();
System.out.println("Enter Emp name");
String enm = sc.next();
System.out.println("Enter Emp Salary");
Float esl = sc.nextFloat();
FileOutputStream fos = null;
ObjectOutputStream oos =null;
Employee e1 = new Employee(eid,enm,esl);
try {
	 fos = new FileOutputStream("EmpObjs.obj");
	 oos = new ObjectOutputStream(fos);
	 oos.writeObject(e1);
	 System.out.println("EMp e1 is written in the file");
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}

	}

}
