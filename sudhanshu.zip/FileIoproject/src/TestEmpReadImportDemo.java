import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class TestEmpReadImportDemo {

	public TestEmpReadImportDemo() {
		// TODO Auto-generated constructor stub
	}
	public static void main(String[]args) {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Emp id");
		int eid = sc.nextInt();
		System.out.println("Enter Emp name");
		String enm = sc.next();
		System.out.println("Enter Emp Salary");
		Float esl = sc.nextFloat();
		DataOutputStream dos = null;
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream("EmpInfo.txt");
			dos = new DataOutputStream(fos);
			//to store in primitve data type
			dos.writeInt(eid);
			dos.writeUTF(enm);
			dos.writeFloat(esl);//even write object is there
			System.out.println("All info written");
			 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
