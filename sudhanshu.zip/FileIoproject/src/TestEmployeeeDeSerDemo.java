import java.io.*;
import java.io.FileNotFoundException;

public class TestEmployeeeDeSerDemo {


	public static void main(String[] args)
	{
		FileInputStream fis=  null;
		ObjectInputStream ois =null;
	try 
	{
		 fis = new FileInputStream("EmpObjs.obj");
		 ois = new ObjectInputStream(fis);
		 Employee ee = (Employee)ois.readObject();
		 System.out.println
		 ("Emp from file :"+ ee);
	}
	catch (ClassNotFoundException | IOException e)// muti catch java 1.7 feature
	{
		
		e.printStackTrace();
	}

	}

}
