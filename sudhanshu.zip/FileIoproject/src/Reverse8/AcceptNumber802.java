package Reverse8;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class AcceptNumber802 {

	public AcceptNumber802() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		File myfile = new File("D:\\sudhanshu\\FileIoproject\\src\\Reverse8\\numbers.txt");

	try {
		Scanner sc = new Scanner(myfile);
		String s=sc.nextLine();
		int p=0;
	String values[]=s.split(",");
	for(int i =0;i<values.length;i++) {
		p= Integer.parseInt(values[i]);
		if(p%2==0) {
			
			System.out.println(values[i]);
		}
	}
		
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
}
}