package Reverse8;

import java.io.*;

public class Reverse801 {

	
public static void main(String[]args) {
		
		File myfile = new File("D:\\sudhanshu\\FileIoproject\\MYFile.txt");//source class
		FileReader fr= null;
		FileReader fr1= null;
		FileWriter fw= null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		BufferedReader br1 = null;
		try {
			
			fr= new FileReader(myfile);

			br= new BufferedReader(fr);
			String line =br.readLine(); 
			//data is read in bytes so in int
			while(line !=null)// till last byte... last byte of file in java is -1
				{
				System.out.println(line);//data is in byte so convert into char
				line = br.readLine();
				
			}
			System.out.println("All data Written in file");
			File myfile1 = new File("D:\\sudhanshu\\FileIoproject\\MYFile.txt");//source class
			fr1= new FileReader(myfile1);
			
			br1= new BufferedReader(fr1);
			fw = new FileWriter("MYfile111.txt");//if file not present the created
			bw= new BufferedWriter(fw);
				
			String 	line1=br1.readLine();
			StringBuilder	sb = new StringBuilder();
				while(line1 !=null )// till last byte... last byte of file in java is -1
				{
				 
				 sb.append(line1);
				 line1=br1.readLine();
				}
				sb=sb.reverse();
			bw.write(sb.toString());
			bw.flush();//flush the data from  buffer to file
System.out.println(sb.toString());
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	} 
}
