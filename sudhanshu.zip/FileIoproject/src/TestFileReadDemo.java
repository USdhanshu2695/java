import java.io.*;

public class TestFileReadDemo {

	public TestFileReadDemo() {
		// TODO Auto-generated constructor stub
	}
	public static void main(String[]args) {

		File myfile = new File("D:\\sudhanshu\\FileIoproject\\src\\TestEMpReadImportDemo.java");//source class
		FileInputStream fis= null;
		try {

			fis= new FileInputStream(myfile);
			int data = fis.read();//data is read in bytes so in int
			while(data !=-1)// till last byte... last byte of file in java is -1
			{
				System.out.println((char)data);//data is in byte so convert into char
				data = fis.read();

			}
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	} 
}
