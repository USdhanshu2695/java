import java.io.*;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;

public class TestFileReadLineDemo {

	public TestFileReadLineDemo() {
		// TODO Auto-generated constructor stub
	}
public static void main(String[]args) {
		
		File myfile = new File("D:\\sudhanshu\\FileIoproject\\MYfile111.txt");//source class
		FileReader fr= null;
		FileWriter fw= null;
		BufferedWriter bw = null;
		BufferedReader br = null;
		try {
			
			fr= new FileReader(myfile);
			fw = new FileWriter("MyFile.txt");//if file not present the created
			bw= new BufferedWriter(fw);
			br= new BufferedReader(fr);
			String line =br.readLine(); 
			//data is read in bytes so in int
			while(line !=null)// till last byte... last byte of file in java is -1
				{
				System.out.println(line);
				bw.write(line);
				bw.flush();//flush the data from  buffer to file
				line = br.readLine();
				
			}System.out.println("All data Written in file");
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	} 
}
