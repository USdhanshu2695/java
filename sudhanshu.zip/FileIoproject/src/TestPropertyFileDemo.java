import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

public class TestPropertyFileDemo {

	public static void main(String[] args)
	{
		FileInputStream fis = null;
		Properties myProps = null;
		try {
	 fis = new FileInputStream("UserInfo.properities");
	 myProps = new  Properties();
	 myProps.load(fis);
	 String unm = myProps.getProperty("userid");
	 String pwd = myProps.getProperty("password");
	 System.out.println("Credential s  "+ unm+ "  "+ pwd);
	 System.out.println("+++++++++++++");
	 
	 
	 
	Set KS =  myProps.keySet();
	
	Iterator it = KS.iterator();
	
	
	while(it.hasNext()) {
		System.out.print(" : "+ it.next());
	}
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}

}
