import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Properties;
import java.io.*;

public class TestPropWriteDemo {

	public static void main(String[] args) 
	{
		FileOutputStream fos = null;
		Properties myDbInfo = null;
try 
{
	
	
	 fos = new FileOutputStream("dbInfo.properties");
	 myDbInfo = new Properties();
	 myDbInfo.setProperty("dbuser", "System");
	 myDbInfo.setProperty("dbpwd", "Root");
	 myDbInfo.store(fos, "This is datbase Information");//store in file
 System.out.println("Data is written in the file");


} 

catch (IOException e)
{
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	}

}
