package com.cg.util;

import java.sql.*;
import java.util.Scanner;

public class TESTEMPSelect {


public static void main(String[] args) {
	Connection con = null;
	Statement st= null;
	ResultSet rs = null;
	
	try {
	
	
Class.forName("oracle.jdbc.driver.OracleDriver");
con= DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G",
	"lab1btrg32","lab1boracle");
 st = con.createStatement();

 rs=st.executeQuery("SELECT * FROM EMP_157795");
 ResultSetMetaData rsmd = rs.getMetaData();
 int colCount = rsmd.getColumnCount();
 System.out.println("No of coumn"+colCount);
 for(int i= 1 ;i<=colCount; i++) {
	 System.out.println(" Column name "+
	 rsmd.getColumnName(i) + "  Column datatype " + rsmd.getColumnTypeName(i));
 }
 
while(rs.next())
	{
	System.out.println(": "+rs.getString("EMP_ID")+":"
+rs.getString("NAME")+": "+rs.getString("SALARY"));
	}
	}
	catch(ClassNotFoundException | SQLException e)
	{
		e.printStackTrace();
		}
	}
}