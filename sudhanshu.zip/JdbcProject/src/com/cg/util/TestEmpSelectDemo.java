package com.cg.util;
import java.sql.*;
import java.util.Scanner;

public class TestEmpSelectDemo {

public static void main(String[] args) {
	Connection con = null;
	PreparedStatement st= null;
	ResultSet rs = null;
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter min salary");
	int minsal= sc.nextInt();
	System.out.println("Enter max salary");
	int maxsal= sc.nextInt();
	String qry="SELECT * FROM EMP_157795 where SALARY>=? and SALARY<=?";
	try {
	
	
Class.forName("oracle.jdbc.driver.OracleDriver");
con= DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G",
	"lab1btrg32","lab1boracle");
 st = con.prepareStatement(qry);
 st.setInt(1,minsal);
 st.setInt(2,maxsal);
 
 rs=st.executeQuery();
while(rs.next())
	{
	System.out.println(": "+rs.getString("EMP_ID")+":"
+rs.getString("NAME")+": "+rs.getString("SALARY"));
	}
	}
	catch(ClassNotFoundException | SQLException e)
	{
		e.printStackTrace();
		}
	}
}
