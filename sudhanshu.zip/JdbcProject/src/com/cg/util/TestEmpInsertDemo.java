package com.cg.util;

import java.sql.*;
import java.util.Scanner;

public class TestEmpInsertDemo {

	public static void main(String[] args) {
		Connection con=null;
		PreparedStatement pst= null;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter empname");
		String empname= sc.next();
		System.out.println("Enter EMP salary");
		int empid= sc.nextInt();
		System.out.println("Enter empid");
		int empsal= sc.nextInt();
		String insertQry = "INSERT INTO EMP_157795 values(?,?,?)";
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con= DriverManager.getConnection
					("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G",
				"lab1btrg32","lab1boracle");
			 pst = con.prepareStatement(insertQry);
			 pst.setInt(1,empid);
			 pst.setString(2,empname);
			
			 pst.setInt(3,empsal);
			 int data = pst.executeUpdate();
			 System.out.println(data+
					 "data is inserted in the table");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
