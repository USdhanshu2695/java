package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class TRY {

	public TRY() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws SQLException {
		Connection con=null;
		PreparedStatement pst= null;
		PreparedStatement pst1= null;

		Scanner sc= new Scanner(System.in);
		//System.out.println("Enter emp name whose salary has to be updated");
	//	String empname= sc.next();
	//System.out.println("Enter EMP salary"); 
	//	int empsal= sc.nextInt();
	//	System.out.println("Enter empid TO BE DELETED");
		//int empid= sc.nextInt();
		System.out.println("Enter empid to update and salary amount");
		int empid1= sc.nextInt();
		int empsal= sc.nextInt();
		
	//	String insertQry = "DELETE FROM table WHERE EMP_ID = ?";
		String insertQry1 = "UPDATE EMP_157795 SET SALARY = ? WHERE EMP_ID = ?";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con= DriverManager.getConnection
					("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G",
				"lab1btrg32","lab1boracle");
		//	 pst = con.prepareStatement(insertQry);
			// pst.setInt(1,empid);
			 pst1 = con.prepareStatement(insertQry1);
			 pst1.setInt(1,empsal);
			 pst1.setInt(2,empid1);
			
			// pst.setInt(3,empsal);
			 int data = pst1.executeUpdate();
			 System.out.println(data+
					 "data is inserted in the table");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}