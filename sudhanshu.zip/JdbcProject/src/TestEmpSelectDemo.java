
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*;

public class TestEmpSelectDemo {

	public static void main(String[] args) {
		Connection con = null;
		Statement st= null;
		ResultSet rs = null;
		try {
		
		
Class.forName("oracle.jdbc.driver.OracleDriver");
con= DriverManager.getConnection("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G",
		"lab1btrg32","lab1boracle");
	 st = con.createStatement();
	 rs=st.executeQuery("SELECT * FROM EMP_157795");
	while(rs.next())
		{
		System.out.println(": "+rs.getString("EMP_ID")+":"
	+rs.getString("NAME")+": "+rs.getString("SALARY"));
		}
		}
		catch(ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
			}
		}

}
