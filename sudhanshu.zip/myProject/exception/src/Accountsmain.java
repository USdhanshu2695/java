

public class Accountsmain {
	class ApplicationException extends Exception {
	    private float detail;
	    ApplicationException(float a) {
	        detail = a;
	     }
		 ApplicationException(String args) {
			super(args);
		 }
	     public String toString()      {
	        return "under age of 15";
	     }
	 }
	

public static void main(String[] args) {
	// TODO Auto-generated method stub
Persons p = new Persons();
p.setAge(10);
float a =p.getAge();
try{
 if (a<=15)
	throw new ApplicationException(a);
}catch(ApplicationException e) {
	System.out.println("caught  "+e);
}
}

}