/**
 * 
 */
package com.capgemini.lesson2;

/**
 * @author ADM-IG-HWDLAB1B
 *
 */
 class BlankException extends Exception
{
	 private String sa;
	 BlankException()
	 {
	 }
	public String toString() {
		return "first name or last name cannot be blank";
	}
	
}
public class Person {

	/**
	 * 
	 */
	private String firstname;
	private String lastname;
	private char gender;
	public Person() {
		// TODO Auto-generated constructor stub
	}
	public Person(String firstname ,String lastname, char gender) {
		// TODO Auto-generated constructor stub
	
		this.firstname = firstname;
		this.lastname = lastname;
		this.gender = gender;
		}
public void setfirstname(String firstname) {
	this.firstname = firstname;
}
public void setlastname(String lastname) {
	this.lastname = lastname;
}
public void setgender(char gender) {
	this.gender = gender;
}
public String getfirstname() {
	return firstname;
}
public String getlastname() {
	return lastname;
}
public char getgender() {
	return gender;
}


	/**
	 * @param args
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Person p1 =new Person();
	
	try{
		if(p1.getfirstname() == null | p1.getlastname() == null)
		{
	throw new BlankException();	
	}
	}
	catch(BlankException e){
		System.out.println("caught :"+ e);
		
	}
	System.out.println("Name :"+p1.getfirstname() + " " + p1.getlastname() + " Gender " + p1.gender);
	Person p2 =new Person("vishar" , "mishra" ,'F');
	System.out.println("Name :"+p2.getfirstname() + " " + p2.getlastname() + " Gender " + p2.gender);

	}

}

