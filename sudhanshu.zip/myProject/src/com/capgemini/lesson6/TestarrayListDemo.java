package com.capgemini.lesson6;

import java.util.ArrayList;
import java.util.Iterator;

public class TestarrayListDemo {


public static void main(String[] args) {
	
ArrayList<Integer> intList = new ArrayList(4);	
Integer i1= new Integer(40);
int i5 =56;
Integer i2= new Integer(10);

Integer i3= new Integer(40);

Integer i4= new Integer(30);
String str3 = new String("Vaishali");
intList.add(i1);
intList.add(i2);
intList.add(i3);
intList.add(i4);
intList.add(i5);
Iterator it = intList.iterator();
while(it.hasNext())
{
System.out.println("Entry "+ it.next());	
}

}
}