package com.capgemini.lesson6;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Warantee {

	public Warantee() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter purchase date IN dd/MM/yyyy");
		DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy");

Scanner s = new Scanner(System.in);
 String input = s.nextLine();

 LocalDate purchase = LocalDate.parse(input,f);
 
 System.out.println("Purchase date is"+ purchase);
 System.out.println("Enter number of months and years");
 
 
	int months = s.nextInt();
	int years = s.nextInt();
	LocalDate wm = purchase.plusMonths(months);
	LocalDate wp =wm.plusYears(years);
System.out.println(wp);
	}

}
