package com.capgemini.lesson6;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class TestHashSetDemo {

public static void main(String []args)
{
HashSet intList = new HashSet(4);//dynanmic size even if we dont give size then it is fine 
Integer i1= new Integer(40);
int i5 =56;
Integer i2= new Integer(10);

Integer i3= new Integer(40);

Integer i4= new Integer(30);

String str3 = new String("Vaishali");
intList.add(i1);
intList.add(i2);
intList.add(i3);
intList.add(i4);
intList.add(i5);
System.out.println(""+intList.size());
Iterator it = intList.iterator();
while(it.hasNext())
{
System.out.println("Entry "+ it.next());	
}

}
}