package com.capgemini.lesson6;
public class emp implements Comparable<emp>{


	public int compareTo(emp e1) {
		// TODO Auto-generated method stub
	if(this.empId<e1.empId) {
		return -1;
	}else if(this.empId==e1.empId) {
		return 0;
	}
	else {
		return 1;
	}
}
public emp() {
	// TODO Auto-generated constructor stub
}
int empId;
float empSal;
String empName;

public emp(int empId,String empName,float empSal) {
super();
this.empId = empId;
this.empSal =  empSal;
this.empName= empName;

}
public String toString() {
return"emp id "+ empId +" empsal  "+ empSal+ "empName"+ empName;
}
@Override
public boolean equals(Object obj)
{
	emp ee= (emp)obj;
	if(this.empId==ee.empId) {
	return	 true;
		
	}
	else {
	return false;
	}
	}
public int hashcode() {
	return empId;
}
}