package com.capgemini.lesson6;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class TestHashMapDemo {

	public TestHashMapDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
HashMap<Long,String> directory =new HashMap();
directory.put(7894561231L, "fewq");
directory.put(9854763210L, "qterw");
directory.put(7894215632L, "erw	");
directory.put(5867941230L, "we	t");
directory.put(9514756895L, "er	w");
directory.put(8785656879L, "	re	ew	t");
System.out.println(directory);
Set<Map.Entry<Long,String>> mapSet = directory.entrySet();
Iterator<Map.Entry<Long,String>> it = mapSet.iterator();
while(it.hasNext()) {
	Map.Entry<Long,String> entry = it.next();
	System.out.println("Key: "+ entry.getKey()+ " Name  "+ entry.getValue());
}
Set<Long> kSet = directory.keySet();
Iterator<Long> itk =  kSet.iterator();



while(itk.hasNext()) {
	Long key= itk.next();
	System.out.println("Key: "+ key);
}


Collection<String> vSet = directory.values();
Iterator<String> ttk =  vSet.iterator();



while(ttk.hasNext()) {
	String value= ttk.next();
	System.out.println("value: "+ value);
}



	}

}
