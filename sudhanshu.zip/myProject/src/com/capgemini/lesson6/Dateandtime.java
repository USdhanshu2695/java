package com.capgemini.lesson6;

import java.time.LocalDate;
import java.time.Period;
import java.time.chrono.ChronoLocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Dateandtime {

	public Dateandtime() {
		// TODO Auto-generated constructor stub
	}
	public static void main(String[] args) {
		/*	DateTimeFormatter is used to configure the date time format
			DateTimeFormatter can also be obtained by using ofPattern() 
			which you can use for custom date and time format
		 */
	
		/*DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter date in dd/MM/yyyy format:");
		String input  = scanner.nextLine();
		
		//Almost every class in java.time package provides parse() method to parse the date or time
		LocalDate enteredDate = LocalDate.parse(input,formatter);
		System.out.println("Entered Date:"+ enteredDate);
		scanner.close();
		}
		catch(Exception e)
		{
			System.out.println("Please enter the date in mentioned format only...");
			
		}
		System.out.println("Hello there");
		*/
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter date in dd/MM/yyyy format:");
			String input  = scanner.nextLine();
			
			//Almost every class in java.time package provides parse() method to parse the date or time
			LocalDate enteredDate = LocalDate.parse(input,formatter);
			System.out.println("Entered Date:"+ enteredDate);
			scanner.close();
		LocalDate currentDate = LocalDate.now();
		Period period = enteredDate.until(currentDate);
		
		System.out.println("Days:"+ period.getDays());
		System.out.println("Months:"+period.getMonths());
		System.out.println("Years:"+ period.getYears());
	}

}
