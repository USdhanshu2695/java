package com.capgemini.lesson6;

import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetDemo1 {

	public TreeSetDemo1() {
		// TODO Auto-generated constructor stub
	}
	public static void main(String []args) {
	TreeSet<emp> empList = new TreeSet<emp>();//output is not unique  it  generates a hash code of every object which is differnt for every object so same object has different object 
		emp e1 = new emp(112081,"Vaishali d ", 9000.00f);

		emp e2 = new emp(14234,"fdsa d ", 1000.00f);

		emp e3 = new emp(4214354,"Vaisfdsahali d ", 9000.00f);

		emp e4 = new emp(432155,"Vaisdsafhali d ", 9000.00f);
		emp e5 = new emp(112081,"Vaishali d ", 9000.00f);

		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		empList.add(e5);
		Iterator<emp> itEmp = empList.iterator();
		while(itEmp.hasNext())
		{
		System.out.println("...."+itEmp.next());	
		}
		}
		}