package com.capgemini.lesson6;
import java.util.Random;
public class Accounts {
	private long accnum;
	private double balance;
	private Persons accholder;
	public Accounts() {
		// TODO Auto-generated constructor stub
	}
	   Random rand = new Random();
	public Accounts(double balance,String name,float age)
	{
		long accnum = rand.nextLong();
		this.balance = balance;
		accholder = new Persons (name,age) ;
	}
	public long getAccnum() {
		return accnum;
	}
	public void setAccnum(long accnum) {
		this.accnum = accnum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Persons getAccholder() {
		return accholder;
	}
	public void setAccholder(Persons accholder) {
		this.accholder = accholder;
	}

	public double deposit () {
		return balance;
		
	}
	public double withdraw (int bal) {
		
		return balance;
		
	}

}
