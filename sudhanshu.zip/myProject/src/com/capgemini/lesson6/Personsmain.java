package com.capgemini.lesson6;

public class Personsmain {

	public Personsmain() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Accounts kathy = new Accounts(3000,"kathy",31);
Accounts smith = new Accounts(2000,"smith",41);
	}

}
