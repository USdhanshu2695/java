package com.capgemini.lesson6;

import java.util.Scanner;

public class Test {

	public Test() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub1
		Scanner sc = new Scanner(System.in);
	System.out.println("How many emp");
	int empCount = sc.nextInt();
	emp emps[] = new emp[empCount];
	for(int i = 0; i<emps.length();i++) 
	{
		System.out.println("Enetr emp id");
		int eId= sc.nextInt();
		System.out.println("Enetr emp name");
		String eName = sc.next();
		System.out.println("Enetr emp sal");
		float eSal = sc.nextFloat();
		emps[i] = new emp(eId,eName,eSal);
	}
	for(emp tempEmp:emps)
	{
		System.out.println(tempEmp));
	}
		
	}
 
	}

