package com.capgemini.lesson6;

public class TestVarArgsDemo {
public int add(String name,int ... nums) {
int sum = 0;
for(int tempNum:nums) {
	sum= sum + tempNum;
}
return sum;
}
	public TestVarArgsDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
TestVarArgsDemo obj1 = new TestVarArgsDemo();
System.out.println("Addition of Number"+obj1.add("sad") );
System.out.println("Addition of Number"+obj1.add("sad",7,8,32,32) );
System.out.println("Addition of Number"+obj1.add("tuuj") );
	}

}
