package com.capgemini.lesson6;

class ApplicationException extends Exception {
    private float detail;
    ApplicationException(float a) {
        detail = a;
     }
	 ApplicationException(String args) {
		super(args);
	 }
     public String toString()      {
        return "under age of 15";
     }
}
public class Persons {
private String name;
private float age;
	public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

public float getAge() {
	return age;
}

public void setAge(float age) {
	this.age = age;
}

	public Persons() {
		// TODO Auto-generated constructor stub
	}
	public Persons(String name,float age) {
		// TODO Auto-generated constructor stub
		this.name = name;
		this.age = age;
	}


	}

