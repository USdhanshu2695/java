package com.capgemini.lesson6;

public  class Account {
private int  balance ;
private  int c;
	public Account() {
		// TODO Auto-generated constructor stub
	}
public static  boolean withdraw(int amount) {
	
c = getBalance() - amount;
	
	if( (balance < SavingsAccount.MINIMUMBALANCE ) | (amount >=CurrentAccount.OVERDRAFTLIMIT))
	{
		balance = balance + amount;	
		System.out.println("Insufficient balance or overdraw amount");
		return false ;
	}
	System.out.println(" balance is"+ balance + " " + "withdrawn Amount "+amount );
	return true;
}
	public int getBalance() {
	return balance;
}
public void setBalance(int balance) {
	this.balance = balance;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
setBalance(5000);
	boolean t = withdraw(1000);
	
	}

}
