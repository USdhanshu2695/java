package com.capgemini.lesson6;

public class CurrentAccount {
	public final static int OVERDRAFTLIMIT = 10000 ;
	
	
	public CurrentAccount() {
		// TODO Auto-generated constructor stub
	}

}
