package com.capgemini.lesson6;

import java.util.HashMap;

public class EmployeeServiceImpl {

	public EmployeeServiceImpl() {
		// TODO Auto-generated constructor stub
	}
public static void main (String args[]) {


	HashMap<String,Employee> list = new HashMap<String,Employee>();
	public void addEmployee(Employee emp)	{
		//code to add employee
}
boolean deleteEmployee(int id)	{
//     code to delete a employee whose id is passed as parameter
}

}
}