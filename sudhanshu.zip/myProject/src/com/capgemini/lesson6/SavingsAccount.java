package com.capgemini.lesson6;

public class SavingsAccount extends Accounts {
public final static int MINIMUMBALANCE = 1000 ;

 public SavingsAccount() {
		// TODO Auto-generated constructor stub
	}

}
