
public class emp {

	public emp() {
		// TODO Auto-generated constructor stub
	}
	int empId;
	float empSal;
	String empName;
	
public emp(int empId,float empSal,String empName) {
	super();
	this.empId = empId;
	this.empSal =  empSal;
	this.empName= empName;
	
}
public String toString() {
	return"emp id "+ empId +" empsal  "+ empSal+ "empName"+ empName;
}
}
