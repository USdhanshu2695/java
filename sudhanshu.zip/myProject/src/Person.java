import java.time.LocalDate;
import java.time.Period;

public class Person {

	
		private String firstname;
		private String lastname;
		private char gender;
		private LocalDate dob;
		private int age;
		public Person() {
			// TODO Auto-generated constructor stub
		}
		public Person(String firstname ,String lastname, char gender) {
			// TODO Auto-generated constructor stub
		
			this.firstname = firstname;
			this.lastname = lastname;
			this.gender = gender;
			}
	public void setfirstname(String firstname) {
		this.firstname = firstname;
	}
	public void setlastname(String lastname) {
		this.lastname = lastname;
	}
	public void setgender(char gender) {
		this.gender = gender;
	}
	public String getfirstname() {
		return firstname;
	}
	public String getlastname() {
		return lastname;
	}
	public char getgender() {
		return gender;
	}
	public int calculateAge(LocalDate dob) {
		this.dob= dob;
		LocalDate currentDate = LocalDate.now();
		Period p = dob.until(currentDate);
		age=p.getYears();
		return age;
	}
	public String getFullName() {
		
		return ( firstname +  lastname );
	}
}
