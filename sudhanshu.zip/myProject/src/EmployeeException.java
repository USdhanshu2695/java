import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class EmployeeException extends Exception {

	public EmployeeException() {

		// TODO Auto-generated constructor stub
	}

	public String toString() {
		return "Salary is under 3000";
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileOutputStream fos = null;
		ObjectOutputStream oos =null;
		System.out.println("Enter no of Emp ");
		
		Scanner sc= new Scanner(System.in);
		int n = sc.nextInt();
		Employee e[] = new Employee[n];
		for(int i = 0;i<n;i++) {
		 e[i] =  new Employee();
		 System.out.println("Enter Emp name");
		 String enm = sc.next();
		 e[i].setName(enm);
		 System.out.println("Enter Emp id");
		 int eid = sc.nextInt();
		 e[i].setId(eid);
		 try
			{
			 fos = new FileOutputStream("EmpObjs.obj");
			 oos = new ObjectOutputStream(fos);
			 oos.writeObject(e[i]);
			if(e[i].getSalary()< 3000)
			{
			throw new EmployeeException();
			}
			}
			catch(EmployeeException r) {
				System.out.println("caught"+r);
				}
		
		 catch (IOException f) {
			
			f.printStackTrace();
		}

		 System.out.println("EMp e1 is written in the file");
	}
	}
}
