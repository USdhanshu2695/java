import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class PersonMain {

	public PersonMain() {
		// TODO Auto-generated constructor stub
	}
public static void main (String[] args) {
	Person p1= new Person("Tinu", "Sharma" ,'M');
	System.out.println("Enter date of birth in dd/MM/yyyy");
	DateTimeFormatter e = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	Scanner sx= new Scanner(System.in);
	String in = sx.nextLine();
	LocalDate dateOfBirth = LocalDate.parse(in,e);
	
	System.out.println("Name :"+p1.getFullName()+ "   age:  " +p1.calculateAge(dateOfBirth)+ "   Gender is :"+p1.getgender());
	
}
}
