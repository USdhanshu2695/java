import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class Timezone {

	public Timezone() {
		// TODO Auto-generated constructor stub
	}
public static String acceptZoneId() {

	Scanner s = new Scanner(System.in);
	String sa = s.nextLine();

return sa;}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter time zone");		
ZonedDateTime current = ZonedDateTime.now(ZoneId.of(acceptZoneId()));
System.out.println(acceptZoneId()+ current);
int hour = current.getHour();
	
int minute = current.getMinute();
int second = current.getSecond();
int day = current.getDayOfMonth();

Month month = current.getMonth();
int year = current.getYear();
System.out.println("hour :"+hour+" minute "+minute+ " second "+second);
System.out.println("day  "+day+" month "+month	+" year " +year);
	}

}
