package com.cg.ems.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.service.EmpService;
import com.cg.ems.service.EmpServiceImpl;

public class TestEmpMGSClient {
 static EmpService empservice = null;
static Scanner sc = null;
	public static void main(String[] args) throws EmployeeException
	{
		sc= new Scanner(System.in);
		empservice = new EmpServiceImpl();
System.out.println("******Welcome to EMS******");
int choice = 0;
while(true) {
	
	System.out.println("What do you want to Do?");
	
	System.out.println("\t 1: Add Emp \t 2: Show All Emp\n"+
	"\t 3: Update Emp  \t  4: Delete Emp\t\n"+"\t  5:  Exit");
	System.out.println("Enter your Choice");
	choice  =sc.nextInt();
	switch(choice)
	{
	case 1: insertEmp();break;
	case 2 : displayAll();break;
	case 3:
	default : System.exit(1);
	
	
	
	}
	}

}
	private static void displayAll() throws EmployeeException {
		ArrayList<Employee> empList=null;
		empList=empservice.getAllEmp();
		System.out.println(" EMPID  EMPNAME  EMPSAL");
		for(Employee ee: empList) {
			System.out.println("\t"+ee.getEmpId()+"\t"+ee.getEmpName() +" \t"+ee.getEmpSal());
		}
	}
	private static void insertEmp() {
		// TODO Auto-generated method stub
		try {	System.out.println("Enter your empid");
		int eId=sc.nextInt();
		System.out.println("Enter name");
		String enm=sc.next();
		Float esl=0.0F;
			if(empservice.validateEmpName(enm)) {
				
				System.out.println("Enter salary");
				 esl=sc.nextFloat();
				 Employee e1 = new Employee(eId,enm,esl);
				 int dataInserted = empservice.addEmp(e1);
				 if (dataInserted ==1) {
					 displayAll();
				 }
				 else {System.out.println("Sorry data is not inserted");
					 }
			}
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	}
