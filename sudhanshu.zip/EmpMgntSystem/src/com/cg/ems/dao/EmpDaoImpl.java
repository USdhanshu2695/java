package com.cg.ems.dao;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.DBUtil;

public class EmpDaoImpl implements EmpDao {

	public EmpDaoImpl() {
		daoLogger = Logger.getLogger(EmpDaoImpl.class);
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	Logger daoLogger= null;
	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs= null;
	@Override
	public ArrayList<Employee> getAllEmp() throws EmployeeException
	{
		ArrayList<Employee> empList= null;
		try 
		{
			empList = new ArrayList<Employee> ();
			con = DBUtil.getConn();
			String selectqry = "SELECT * FROM  emp_157795";
			st=con.createStatement();
			rs= st.executeQuery(selectqry);
			while(rs.next())
			{
				empList.add(new Employee (rs.getInt("emp_id"),rs.getString("NAME"),rs.getInt("SALARY")));
			}
		} 
		catch (Exception e) 
		{
			daoLogger.error(e.getMessage());
			throw new EmployeeException(e.getMessage());
		} 
		finally 
		{
			try 
			{
				st.close();
				rs.close();
				con.close();
			} catch (SQLException e)
			{
				throw new EmployeeException(e.getMessage());
			}

		}
		daoLogger.info("All data retrived"+empList);
		return empList;   
	}


	@Override
	public int addEmp(Employee ee) throws EmployeeException {

		int data = 0;
		try 
		{
			con=DBUtil.getConn();
			String insertQry= "INSERT INTO EMP_157795 VALUES(?,?,?) "; 
			pst=con.prepareStatement(insertQry);
			pst.setInt(3, ee.getEmpId());
			pst.setString(1, ee.getEmpName());
			pst.setFloat(2, ee.getEmpSal());
			data = pst.executeUpdate();
		} 
		catch (Exception e)
		{

			e.printStackTrace();
		} 


		return data;
	}

}
