package com.cg.ems.exception;


import com.cg.ems.dto.Employee;

public class EmployeeException extends Exception
{
	 String msg;
	 static ErrorCode code;
	
	public EmployeeException(String msg,Throwable cause,ErrorCode code) {
		super(msg,cause);
		this.code = code;
	}
	public	EmployeeException(String msg) {
	
		super (msg);	

}

}