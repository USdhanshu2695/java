package com.cg.ems.util;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.*;

public class DBUtil {
static String driver = null;
static String url = null;
static String unm = null;
static String pwd = null;
	public DBUtil() {
		
	}
	public static Connection getConn() throws SQLException, IOException {
		
		Properties myprops = loadDBInfo();
		url = myprops.getProperty("dbUrl");
		unm = myprops.getProperty("dbUser");
		pwd = myprops.getProperty("dbPassword");
        driver = myprops.getProperty("dbDriver");
		Connection con = null;
		if(con==null) {
			con = DriverManager.getConnection(url,unm,pwd);
			return con;
		}
		else {
			return con;
		}

	}
	public static Properties loadDBInfo() throws IOException 
	{
		FileReader fr = new FileReader("D:\\sudhanshu\\EmpMgntSystem\\src\\dbInfo.properties");
	Properties dbProps = new Properties();
	dbProps.load(fr);
	return dbProps;
	}

}
