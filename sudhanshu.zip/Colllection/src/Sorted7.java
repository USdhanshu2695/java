import java.util.Iterator;
import java.util.TreeSet;

public class Sorted7 {

	public Sorted7() {
		// TODO Auto-generated constructor stub
	}
public static void main(String []args) {
	
	TreeSet<String> prodList = new TreeSet();
	String s1= new String("ac");
	String s2= new String("fac");
	String s3= new String("gaac");
	String s4= new String("acgasdg");
	String s5= new String("fridge");
	String s6= new String("tv");
	String s7= new String("washing");
	prodList.add(s1);
	prodList.add(s2);
	prodList.add(s3);
	prodList.add(s4);
	prodList.add(s5);
	prodList.add(s6);
	prodList.add(s7);
	Iterator<String> it= prodList.iterator();
	while(it.hasNext()) {
		System.out.println("....."+it.next());
	}
}
}
