package a;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;



public class EmployeeServiceImpl {

Employee employee;
	static HashMap<String,Employee> list = new HashMap<String,Employee>();  
		
	public static void addEmployee(Employee emp)	{
			//code to add employee
		Employee emp1 = emp;
		System.out.println("Enter the name of employee");
		Scanner S = new Scanner (System.in);
		String name = S.next(); 
		emp1.setName(name);
		list.put(name, emp1);
		System.out.println(list);
	}
	
	public static boolean deleteEmployee(int id)	{
		Collection<Employee> vSet = list.values();
		//Iterator<Employee> ttk =  vSet.iterator();
		System.out.println(vSet);
		boolean flag = false;
		for(Employee value:vSet) {
			
			if(value.getId()==id  ) {
				flag = true;
				list.remove(value.getName(),value);
				System.out.println("Employee name "+value.getName() + "is deleted");

			
			}
			
		}
		return flag;
	

//	     code to delete a employee whose id is passed as parameter
	}
	
	public static void main(String args[]) {
		int i;
		System.out.println("Enter no. of employee ");
		Scanner sc = new Scanner(System.in);
		String designation = null;
		String insuranceScheme = null;
		int n = sc.nextInt();
		
		Employee err[]=new Employee[n];
		for( i = 0; i<n;i++) {
			 err[i]=new Employee();
			System.out.println("Enter  employee id ");
			int id= sc.nextInt();
			err[i].setId(id);
			System.out.println("Enter  employee name ");
			String name= sc.next();
			err[i].setName(name);
			System.out.println("Enter  employee Salary ");
			double salary= sc.nextDouble();
			err[i].setSalary(salary);
			if (salary>5000 && salary<20000) {
				 designation = "System Associate";
				 err[i].setDesignation(designation);
				 insuranceScheme = "Scheme A";
				 err[i].setInsuranceScheme(insuranceScheme);
			}
			else if (salary>=20000 && salary<40000) {
				 designation = "Programmer ";				 err[i].setDesignation(designation);
				 insuranceScheme = "Scheme B";err[i].setInsuranceScheme(insuranceScheme);
			}
			else if (salary>=40000 ) {
			 designation = "Manager ";				 err[i].setDesignation(designation);
				 insuranceScheme = "Scheme C";err[i].setInsuranceScheme(insuranceScheme);
			}
			else if (salary<5000 ) {
				 designation = "Clerk ";				 err[i].setDesignation(designation);
				 insuranceScheme = "No Scheme";err[i].setInsuranceScheme(insuranceScheme);
			}
			
			
			list.put(name, err[i]);
			
		}
		int i4=1;
		while( i4==1) {
		System.out.println("Enter  the choice     1.To add new employee   2.To delete a employee                     3.to exit                           ");
		int i1 = sc.nextInt();
		if(i1 == 1) {
			Employee emp2 = new Employee();
			System.out.println("Enter  employee id ");
			int id= sc.nextInt();
			emp2.setId(id);
	
			System.out.println("Enter  employee Salary ");
			double salary= sc.nextDouble();
			emp2.setSalary(salary);
			if (salary>5000 && salary<20000) {
				 designation = "System Associate";
				 emp2.setDesignation(designation);
				 insuranceScheme = "Scheme A";
				 emp2.setInsuranceScheme(insuranceScheme);

			}
			else if (salary>=20000 && salary<40000) {
				 designation = "Programmer ";
				 insuranceScheme = "Scheme B";
			}
			else if (salary>=40000 ) {
			 designation = "Manager ";
				 insuranceScheme = "Scheme C";
			}
			else if (salary<5000 ) {
				 designation = "Clerk ";
				 insuranceScheme = "No Scheme";
			}
			addEmployee(emp2);
			n++;
		}
		else if (i1 == 2) {
			System.out.println("Enter  the empoyee id of the employee to be deleted"); 
			int id = sc.nextInt();
			boolean flag = deleteEmployee(id);
			n--;
			if( flag == false) {
				System.out.println("Employee not found");	
				
			}
		}
		else if(i1 == 3) {
			i4=0;
			break;
		}
		else {
			System.out.println("Enter  Valid choice"); 
		}
	}
		System.out.println("Enter the insurance scheme");
	 sc.nextLine();
		 insuranceScheme = sc.nextLine();
		 
		
		
		Collection<Employee> vSet1 = list.values();
		Iterator<Employee> ttk1 =  vSet1.iterator();



		while(ttk1.hasNext()) {
			Employee value= ttk1.next();
			String is =value.getInsuranceScheme();
			if(is.equals(insuranceScheme))
			System.out.println(value.getId()+"Employee id found")		;
			}
	
	TreeSet<Employee> intList = new TreeSet<Employee>(); //dynanmic size even if we dont give size then it is fine 
	Collection<Employee> vSet = list.values();
	//Iterator<Employee> ttk =  vSet.iterator();
	
	boolean flag = false;
	for(Employee value:vSet) {
		intList.add(value);
		System.out.println("Entry "+ value);

		
	}
	
	System.out.println("Size of employee list"+intList.size());
	
}
	}
