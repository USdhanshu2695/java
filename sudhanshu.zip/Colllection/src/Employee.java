import java.util.Scanner;

public class Employee {
	private int id;
	private String name;
	private Double  salary;
	private String designation;
	private String insuranceScheme;
	public int getId() {
		return id;
	}
	public Employee(int id, String name, Double salary, String designation, String insuranceScheme) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		this.insuranceScheme = insuranceScheme;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getInsuranceScheme() {
		return insuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		this.insuranceScheme = insuranceScheme;
	}
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String args[]) {
		System.out.println("Enter no. of employee ");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		Employee err[] = new Employee[n];
		for(int i = 0; i<n;i++) {
			System.out.println("Enter  employee id ");
			int id= sc.nextInt();
			System.out.println("Enter  employee name ");
			String name= sc.nextLine();
			System.out.println("Enter  employee designation ");
			String designation= sc.nextLine();
			System.out.println("Enter  employee insuranceScheme ");
			String insuranceScheme= sc.nextLine();
			System.out.println("Enter  employee Salary ");
			double salary= sc.nextDouble();
			err[i] = new Employee(id,name,salary,designation,insuranceScheme);
			sc.close();
		}
	}
}

