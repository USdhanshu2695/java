import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeSet;

public class ArrayList7 {

	public ArrayList7() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> prodList = new ArrayList();
		String s1= new String("ac");
		String s2= new String("fac");
		String s3= new String("gaac");
		String s4= new String("acgasdg");
		String s5= new String("fridge");
		String s6= new String("tv");
		String s7= new String("washing");
		prodList.add(s1);
		prodList.add(s2);
		prodList.add(s3);
		prodList.add(s4);
		prodList.add(s5);
		prodList.add(s6);
		prodList.add(s7);
		
		Collections.sort(prodList);
		for(String name: prodList) {
			System.out.println(name);
			System.out.println();
		}
	}
}
