package com.cg.mps.ui;



import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mps.dto.Mobile;
import com.cg.mps.dto.Purchase;
import com.cg.mps.exception.MobileException;
import com.cg.mps.service.MobileService;
import com.cg.mps.service.MobileServiceImpl;


public class TestMobileMPSClient {
	static MobileService mobileService = null;
	static Scanner sc = null;
	public static void main(String[] args) throws MobileException
	{
		sc= new Scanner(System.in);
		mobileService = new MobileServiceImpl();
		System.out.println("******Welcome to MPS******");
		int choice = 0;
		while(true) {

			System.out.println("What do you want to Do?");

			System.out.println("\t 1: Show mobile details \t 2: Show All purchase details\n"+
					"\t 3: Purchase of mobile  \t  4: Delete mobile in mobiles\t\n"+
					"\t  5:Search mobile based on price range"+"\t  6:Exit");
			System.out.println("Enter your Choice");
			choice  =sc.nextInt();
			switch(choice)
			{
			case 1: displayAllMobile();break;
			case 2 : displayAllPurchaseDetails();break;
			case 3:insertEmp();break;
			case 4:deleteMobile();break;
			case 5:searchEmp();break;


			default : System.exit(1);



			}
		}

	}
	private static void displayAllMobile() throws MobileException {
		ArrayList<Mobile> empList=null;
		empList=mobileService.getAllMobile();
		System.out.println("           MobileId  Name        Price  Quantity");
		for(Mobile ee: empList) {
			System.out.println("\t"+ee.getMobileId()+"\t"+ee.getName() +" \t"+ee.getPrice()+" \t"+ee.getQuantity());
		}
	}
	private static void displayAllPurchaseDetails() throws MobileException {
		ArrayList<Purchase> empList=null;
		empList=mobileService.getAllPurchaseDetails();
		System.out.println(" PurchaseId  Name        mail            phone              purchaseDate  Price  Quantity");
		for(Purchase ee: empList) {
			System.out.println("\t"+ee.getPurchaseId()+"\t"+ee.getcName() +
					" \t"+ee.getMailId()+" \t"+ee.getPhoneNo()+
					"\t"+ee.getPurchaseDate()+" \t"+ee.getMobileId());
		}
	}
	private static void insertEmp() {
		// TODO Auto-generated method stub
		try {	System.out.println("Enter your name");
		String cnm=sc.next();
		System.out.println("Enter your mail id");
		String cmi=sc.next();
		System.out.println("Enter your phone no");
		String cpn=sc.next();
		System.out.println("Enter mobileid");
		int mid=sc.nextInt();
		boolean first = false;
		boolean second = false;
		boolean third = false;
		boolean fourth=false;
		first=mobileService.validateCName(cnm);
		second=mobileService.validateMailId(cmi);
		third=mobileService.validatePhoneNo(cpn);
		fourth = mobileService.validateMobileId(mid);
		if(first && second && third) {


			Purchase e1 = new Purchase(cnm,cmi,cpn,mid);
			int dataInserted = mobileService.mobilePurchased(e1,mid);
			if (dataInserted ==1) {
				displayAllMobile();
				displayAllPurchaseDetails();
			}
			else {System.out.println("Sorry data is not inserted");
			}
		}
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	private static void deleteMobile() {
		System.out.println("Enter the mobile id to be deleted");
		int mid= sc.nextInt();
		int dataInserted = 0;
		try {
			dataInserted = mobileService.deleteMobile(mid);
			if (dataInserted ==1) {
				displayAllMobile();
				displayAllPurchaseDetails();
			}
			else {System.out.println("Sorry data is not deleted");
			}
		} catch (MobileException e) {
			e.printStackTrace();
			// TODO Auto-generated catch block

		}

	}
	private static void searchEmp() {
		ArrayList<Mobile> dataInserted =null;
		System.out.println("Enter the minimum price ");
		int min= sc.nextInt();
		System.out.println("Enter the maximum price");
		int max= sc.nextInt();
		try {
			dataInserted = mobileService.getAllMobile(min, max);

		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
