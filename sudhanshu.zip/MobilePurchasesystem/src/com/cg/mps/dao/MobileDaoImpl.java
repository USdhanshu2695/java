package com.cg.mps.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;


import com.cg.mps.dto.Mobile;
import com.cg.mps.dto.Purchase;
import com.cg.mps.exception.MobileException;
import com.cg.mps.util.DBUtil;



public class MobileDaoImpl implements MobileDao{

	public MobileDaoImpl() {
		
	}
	
	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	PreparedStatement pst1 = null;
	ResultSet rs= null;
	@Override
	public ArrayList<Mobile> getAllMobile() throws MobileException
	{
		ArrayList<Mobile> mobileList= null;
		try 
		{
			mobileList = new ArrayList<Mobile> ();
			con = DBUtil.getConn();
			String selectqry = "SELECT * FROM  MOBILE_157795";
			st=con.createStatement();
			rs= st.executeQuery(selectqry);
			while(rs.next())
			{
				mobileList.add(new Mobile (rs.getInt("MOBILEID"),rs.getString("NAME"),rs.getInt("PRICE"),rs.getString("QUANTITY")));
			}
		} 
		catch (Exception e) 
		{
			
			throw new MobileException(e.getMessage());
		} 
		finally 
		{
			try 
			{
				st.close();
				rs.close();
				con.close();
			} catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}

		}
		
		return mobileList;   
	}
	@Override
	public ArrayList<Purchase> getAllPurchaseDetails() throws MobileException
	{
		ArrayList<Purchase> purchaseList= null;
		try 
		{
			purchaseList = new ArrayList<Purchase> ();
			con = DBUtil.getConn();
			String selectqry = "SELECT * FROM  PURCHASEDETAIL_157795";
			st=con.createStatement();
			rs= st.executeQuery(selectqry) ; 
			while(rs.next())
			{
				purchaseList.add(new Purchase (rs.getInt("PURCHASEId"),rs.getString("CNAME"),rs.getString("MAILID"),rs.getString("PHONENO"),rs.getDate("PURCHASEDATE"),rs.getInt("MOBILEID")));
			}
		} 
		catch (Exception e) 
		{
			
			throw new MobileException(e.getMessage());
		} 
		finally 
		{
			try 
			{
				st.close();
				rs.close();
				con.close();
			} catch (SQLException e)
			{
				throw new MobileException(e.getMessage());
			}

		}
		
		return purchaseList;   
	}


	@Override
	public int mobilePurchased( Purchase ee) throws MobileException {

		int data = 0;
		try 
		{
			con=DBUtil.getConn();
			
			
			
					String insertQry= "INSERT INTO PURCHASEDETAIL_157795 (purchaseid,cname,mailid,phoneno,purchasedate,mobileid)VALUES(seq.nextval,?,?,?,?,?) "; 
					
					pst=con.prepareStatement(insertQry);
					
					pst.setString(1, ee.getcName());
					pst.setString(2, ee.getMailId());
					pst.setString(3, ee.getPhoneNo());
					pst.setDate(4,  ee.getPurchaseDate());
					pst.setInt(5, ee.getMobileId());
					data = pst.executeUpdate();
		 
			
		
			
		} 
		catch (Exception e)
		{

			throw new MobileException(e.getMessage());
		} 


		return data;
	}
	@Override
	public int deleteMobile(int mobId) throws MobileException {
		// TODO Auto-generated method stub
		int data = 0;
		int data1 = 0;
		try {
			con=DBUtil.getConn();
			
			
			
			String insertQry= "DELETE FROM PURCHASEDETAIL_157795 WHERE MOBILEID=?"; 
			 

			
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, mobId);
			data = pst.executeUpdate();
			String insertQry1= "DELETE FROM MOBILE_157795 WHERE MOBILEID=?";
			pst1=con.prepareStatement(insertQry1);
			
				pst1.setInt(1, mobId);
				
				data1 = pst1.executeUpdate();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				throw new MobileException(e.getMessage());
			}
		return data;
				
	}
	@Override
	public ArrayList<Mobile> getAllMobile(int min,int max) throws MobileException
	{
		ArrayList<Mobile> mobileList1= null;		// TODO Auto-generated method stub
		try {
			con=DBUtil.getConn();
			String insertQry= "SELECT * FROM MOBILE_157795 where PRICE>=? and PRICE<=?";
			
			pst=con.prepareStatement(insertQry);
			pst.setInt(1,min);
			 pst.setInt(2,max);
			 rs=pst.executeQuery();
			 while(rs.next())
			 	{
			 	System.out.println(rs.getInt("MOBILEID")+rs.getString("NAME")+rs.getInt("PRICE")+rs.getString("QUANTITY"));
			 	}
			 	
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new MobileException(e.getMessage());
		}
		return mobileList1;
		
		
	}
	
	
	


}