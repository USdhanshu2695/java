package com.cg.mps.dao;

import java.util.ArrayList;


import com.cg.mps.dto.Mobile;
import com.cg.mps.dto.Purchase;
import com.cg.mps.exception.MobileException;



public interface MobileDao {
	public ArrayList<Mobile> getAllMobile()throws MobileException;
	public ArrayList<Purchase> getAllPurchaseDetails() throws MobileException;
	
	public int mobilePurchased(Purchase ee) throws MobileException;

public int deleteMobile(int mobId) throws MobileException;
public ArrayList<Mobile> getAllMobile(int min, int max) throws MobileException;
	}
