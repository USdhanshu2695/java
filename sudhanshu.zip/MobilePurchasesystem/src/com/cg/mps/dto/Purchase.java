package com.cg.mps.dto;
import java.util.*;
import java.sql.Date;

import java.text.SimpleDateFormat;
import java.time.LocalDate;


public class Purchase {
private  int purchaseId = 0;
private String cName;
private String mailId;
private String phoneNo;
private Date purchaseDate;
private int mobileId;
public Purchase(int purchaseId,String cName, String mailId, String phoneNo, Date purchaseDate, int mobileId) {
	super();
	this.cName = cName;
	this.mailId = mailId;
	this.phoneNo = phoneNo;
	this.purchaseDate = purchaseDate;
	this.mobileId = mobileId;
	this.purchaseId=purchaseId;
}
public Purchase(String cName, String mailId, String phoneNo, Date purchaseDate, int mobileId) {
	super();
	this.cName = cName;
	this.mailId = mailId;
	this.phoneNo = phoneNo;
	this.purchaseDate = purchaseDate;
	this.mobileId = mobileId;
}
SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
@Override
public String toString() {
	return "Purchase [purchaseId=" + purchaseId + ", cName=" + cName + ", mailId=" + mailId + ", phoneNo=" + phoneNo
			+ ", purchaseDate=" + purchaseDate + ", mobileId=" + mobileId + "]";
}
public Purchase( String cName, String mailId, String phoneNo, int mobileId) {
	super();
	this.cName = cName;
	this.mailId = mailId;
	this.phoneNo = phoneNo;
	
	//java.sql.Date sqlDate = new java.sql.Date(Calendar.getInstance().getTimeInMillis());
	this.purchaseDate =  Date.valueOf(LocalDate.now());
	this.mobileId = mobileId;
}
public int getPurchaseId() {
	return purchaseId;
}

public String getcName() {
	return cName;
}
public void setcName(String cName) {
	this.cName = cName;
}
public String getMailId() {
	return mailId;
}
public void setMailId(String mailId) {
	this.mailId = mailId;
}
public String getPhoneNo() {
	return phoneNo;
}
public void setPhoneNo(String phoneNo) {
	this.phoneNo = phoneNo;
}
public Date getPurchaseDate() {
	
	return purchaseDate;
}
public void setPurchaseDate(Date purchaseDate) {
	this.purchaseDate = purchaseDate;
}
public int getMobileId() {
	return mobileId;
}
public void setMobileId(int mobileId) {
	this.mobileId = mobileId;
}


}
