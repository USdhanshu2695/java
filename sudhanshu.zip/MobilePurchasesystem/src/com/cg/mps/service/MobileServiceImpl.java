package com.cg.mps.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.cg.mps.dao.MobileDao;
import com.cg.mps.dao.MobileDaoImpl;
import com.cg.mps.dto.Mobile;
import com.cg.mps.dto.Purchase;
import com.cg.mps.exception.MobileException;
import com.cg.mps.util.DBUtil;

public class MobileServiceImpl implements MobileService  {
	Scanner sc =new Scanner(System.in);
	Connection con = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs= null;

	MobileDao mobDao = null;
	public MobileServiceImpl() {
		mobDao =new MobileDaoImpl();
	}

	@Override
	public ArrayList<Mobile> getAllMobile() throws MobileException {
		// TODO Auto-generated method stub
		return mobDao.getAllMobile();
	}

	@Override
	public ArrayList<Purchase> getAllPurchaseDetails() throws MobileException {
		// TODO Auto-generated method stub
		return mobDao.getAllPurchaseDetails();
	}

	@Override
	public int mobilePurchased(Purchase ee,int mid) throws MobileException {
		int data =0;
		int data1 = 0;
		
		int first=0;
		int second =0;
		String mobileqQy = "SELECT * FROM  MOBILE_157795  ";
		try {
			con=DBUtil.getConn();
			st=con.createStatement();
			rs= st.executeQuery(mobileqQy);
			while(rs.next())
			{
				first=(rs.getInt("MOBILEID"));
				second=Integer.parseInt(rs.getString("QUANTITY"));
				if((first==mid)&& (second>=1))
				{
					
					data= mobDao.mobilePurchased(ee);
					int a=Integer.parseInt(rs.getString("QUANTITY"));
					
				--a;
				Integer i = new Integer(a);
				String as=i.toString();
					String updateQy =	"UPDATE MOBILE_157795 SET QUANTITY = ? WHERE MOBILEID=?";
					con=DBUtil.getConn();
					pst = con.prepareStatement(updateQy);
					pst.setString(1,as);
					pst.setInt(2,mid);


					data1 = pst.executeUpdate();


				}
			}
			if(data==0) {
				throw new MobileException("Mobile not available");
			}
			if(data1==0) {
				throw new MobileException("Mobiles updated");
			}
		}
		catch (Exception e) {
			// TODO Auto-generated catch block
			throw new MobileException(e.getMessage());
		}
		return data1;

	}


	@Override
	public int deleteMobile(int mobId) throws MobileException {
		// TODO Auto-generated method stub
		return mobDao.deleteMobile(mobId);
	}

	@Override
	public ArrayList<Mobile> getAllMobile(int min, int max) throws MobileException {
		// TODO Auto-generated method stub
		return mobDao.getAllMobile(min, max);
	}

	@Override
	public boolean validateCName(String cName) throws MobileException {
		// TODO Auto-generated method stub
		String namePattern="[A-Z][a-z]+";
		if (Pattern.matches(namePattern, cName)){
			return true;
		}
		else {
			throw new MobileException
			("Invalid Employee name.Should start with capital "+
			"only characters allowed");
		}
	}

	@Override
	public boolean validateMailId(String mailId) throws MobileException {
		 {
		        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
		                            "[a-zA-Z0-9_+&*-]+)*@" +
		                            "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
		                            "A-Z]{2,7}$";
		                             
		        if (Pattern.matches(emailRegex, mailId)){
		        	return true;
		        	}
		        	else
		        	{	throw new MobileException
					("Invalid Employee email id.") ;}
		        
		    }
	}

	@Override
	public boolean validatePhoneNo(String phoneNo) throws MobileException {
		// TODO Auto-generated method stub
		 Pattern p = Pattern.compile("[5-9][0-9]{9}");
		 
	        // Pattern class contains matcher() method
	        // to find matching between given number 
	        // and regular expression
	        Matcher m = p.matcher(phoneNo);
	       if( (m.find() && m.group().equals(phoneNo))) {
	    	   return true;
	       }else
	    	   
       	{	throw new MobileException("Invalid customers email id.") ;}
	}
	

	@Override
	public boolean validateMobileId(int mobileId) throws MobileException {
		// TODO Auto-generated method stub
		String mobileqQy = "SELECT * FROM  MOBILE_157795  ";
		int d=0;
		boolean flag = false;
		try {
			con=DBUtil.getConn();
			st=con.createStatement();
			rs= st.executeQuery(mobileqQy);
			while(rs.next())
			{
				d=rs.getInt("MOBILEID");
				if((d==mobileId))
				{ flag=true;
					return true;
				
					
				}
				  
				}
			 if(flag==false)
		    	   
		    	{	throw new MobileException("Invalid Mobileid.") ;}
			}
		catch (Exception e) {
			// TODO Auto-generated catch block
			throw new MobileException(e.getMessage());
		}
		return true;
	  
	}
	}


