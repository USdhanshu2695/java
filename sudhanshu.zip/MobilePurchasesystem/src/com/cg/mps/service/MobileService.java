package com.cg.mps.service;

import java.util.ArrayList;


import com.cg.mps.dto.Mobile;
import com.cg.mps.dto.Purchase;
import com.cg.mps.exception.MobileException;



public interface MobileService {
	public ArrayList<Mobile> getAllMobile()throws MobileException;
	public ArrayList<Purchase> getAllPurchaseDetails() throws MobileException;
	
	public int mobilePurchased(Purchase ee,int mid) throws MobileException;

public int deleteMobile(int mobId) throws MobileException;
public ArrayList<Mobile> getAllMobile(int min, int max) throws MobileException;
public boolean validateCName(String cName) throws MobileException;
public boolean validateMailId(String mailId) throws MobileException;
public boolean validatePhoneNo(String phoneNo) throws MobileException;
public boolean validateMobileId(int mobileId) throws MobileException;









	}
