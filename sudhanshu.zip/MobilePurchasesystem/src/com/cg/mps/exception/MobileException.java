package com.cg.mps.exception;



public class MobileException extends Exception {

	
		 String msg;
		 static ErrorCode code;
		
		public MobileException(String msg,Throwable cause,ErrorCode code) {
			super(msg,cause);
			this.code = code;
		}
		public	MobileException(String msg) {
		
			super (msg);	

	}

	}