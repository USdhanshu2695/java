


	import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Iterator;
	import java.util.Properties;
	import java.util.Set;

	public class CreayingProps {
		public static void main(String[] args) throws IOException
		{
			FileOutputStream fos = null;
			Properties myDbInfo = null;
			FileInputStream fis = null;
			Properties myProps = null;
	try 
	{
		
		
		 fos = new FileOutputStream("PersonProps.properties");
		 myDbInfo = new Properties();
		 myDbInfo.setProperty("dbuser", "System");
		 myDbInfo.setProperty("dbpwd", "Root");
		 myDbInfo.setProperty("dbuser1", "Sy2stem");
		 myDbInfo.setProperty("dbpwd1", "Ro2ot");
		 myDbInfo.setProperty("dbuser2", "Sy2stem");
		 myDbInfo.setProperty("dbpwd2", "Ro2ot");
		 myDbInfo.store(fos, "This is datbase Information");//store in file
	 System.out.println("Data is written in the file");
	
	 


	} 

	catch (IOException e)
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	 try {
		fis = new FileInputStream("PersonProps.properties");
	} 
	 catch (FileNotFoundException e) {
		
		e.printStackTrace();
	}
	 myProps = new  Properties();
	 myProps.load(fis);
	 String unm = myProps.getProperty("dbuser1");
	 String pwd = myProps.getProperty("dbpwd1");
	 System.out.println("Credential s  "+ unm+ "  "+ pwd);
	  unm = myProps.getProperty("dbuser");
	 pwd = myProps.getProperty("dbpwd");
	 System.out.println("Credential s  "+ unm+ "  "+ pwd);
	  unm = myProps.getProperty("dbuser2");
	  pwd = myProps.getProperty("dbpwd2");
	 System.out.println("Credential s  "+ unm+ "  "+ pwd);
	 System.out.println("+++++++++++++");}

	}

