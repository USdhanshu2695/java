
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.TreeSet;
 

public class EmployeeServiceImpl {

//Employee employee;
	//static HashMap<String,Employee> list = new HashMap<String,Employee>();  
	
	/*public static void addEmployee(Employee emp)	{
			//code to add employee
		Employee emp1 = emp;
		System.out.println("Enter the name of employee");
		Scanner S = new Scanner (System.in);
		String name = S.next(); 
		emp1.setName(name);
		list.put(name, emp1);
		System.out.println(list);
	}
	*/
	public static void deleteEmployee(int id)	{
		//Collection<Employee> vSet = list.values();
		//Iterator<Employee> ttk =  vSet.iterator();
		//System.out.println(vSet);
		try {
			Connection con=null;
			PreparedStatement pst= null;
			String insertQry = "DELETE FROM EMPLOYEE_157795 WHERE ID=?";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con= DriverManager.getConnection
					("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G",
				"lab1btrg32","lab1boracle");
			 pst = con.prepareStatement(insertQry);
			 pst.setInt(1,id);
		
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 
		
	/*	for(Employee value:vSet) {
			
			if(value.getId()==id  ) {
				flag = true;
				list.remove(value.getName(),value);
				System.out.println("Employee name "+value.getName() + "is deleted");
*/
			
			
		
		}
		
	

//	     code to delete a employee whose id is passed as parameter
	
	
	public static void main(String args[]) throws SQLException {
		int i;
		Connection con=null;
		PreparedStatement pst= null;
		Scanner sc= new Scanner(System.in);	
		System.out.println("Enter no. of employee ");
		
		String designation = null;
		String insuranceScheme = null;
		int n = sc.nextInt();
		String insertQry = "INSERT INTO EMPLOYEE_157795 values(?,?,?,?,?)";

		
		 
		 
		 
	//	Employee err[]=new Employee[n];
		for( i = 0; i<n;i++) {
		//	 err[i]=new Employee();
			System.out.println("Enter  employee id ");
			int id= sc.nextInt();
			
			//err[i].setId(id);
			System.out.println("Enter  employee name ");
			String name= sc.next();
			 //	err[i].setName(name);
			System.out.println("Enter  employee Salary ");
			int salary= sc.nextInt();
			 	//	err[i].setSalary(salary);
			if (salary>5000 && salary<20000) {
				 designation = "System Associate";
				// err[i].setDesignation(designation);
				 insuranceScheme = "Scheme A";
				// err[i].setInsuranceScheme(insuranceScheme);
			}
			else if (salary>=20000 && salary<40000) {
				 designation = "Programmer ";	//pst.setString(3,designation);			// err[i].setDesignation(designation);
				 insuranceScheme = "Scheme B";//pst.setString(4,insuranceScheme);//err[i].setInsuranceScheme(insuranceScheme);
			}
			else if (salary>=40000 ) {
			 designation = "Manager ";			// err[i].setDesignation(designation);
				 insuranceScheme = "Scheme C";//err[i].setInsuranceScheme(insuranceScheme);
			}
			else if (salary<5000 ) {
				 designation = "Clerk ";		//pst.setString(3,designation);	//	 err[i].setDesignation(designation);
				 insuranceScheme = "No Scheme";//pst.setString(4,insuranceScheme);//err[i].setInsuranceScheme(insuranceScheme);
			}
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con= DriverManager.getConnection
						("jdbc:oracle:thin:@10.51.103.201:1521:ORCL11G",
					"lab1btrg32","lab1boracle");
				 pst = con.prepareStatement(insertQry);
			 pst.setString(1,name);
			 pst.setInt(2,salary);
			 pst.setString(3,designation);
			 pst.setString(4,insuranceScheme);
			 pst.setInt(5,id);
			 int data = pst.executeUpdate();
			 System.out.println(data+
					 "data is inserted in the table");}
			catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			//list.put(name, err[i]);
			
		}
		int i4=1;
		while( i4==1) {
		System.out.println("Enter  the choice       2.To delete a employee                     3.to exit                           ");
		int i1 = sc.nextInt();
		 if (i1 == 2) {
			System.out.println("Enter  the empoyee id of the employee to be deleted"); 
			int id = sc.nextInt();
			 deleteEmployee(id);
			
			
		}
		else if(i1 == 3) {
			i4=0;
			break;
		}
		else {
			System.out.println("Enter  Valid choice"); 
		}
	}
		/*System.out.println("Enter the insurance scheme");
	 sc.nextLine();
		 insuranceScheme = sc.nextLine();
		 
		
		
		Collection<Employee> vSet1 = list.values();
		Iterator<Employee> ttk1 =  vSet1.iterator();



		while(ttk1.hasNext()) {
			Employee value= ttk1.next();
			String is =value.getInsuranceScheme();
			if(is.equals(insuranceScheme))
			System.out.println(value.getId()+"Employee id found")		;
			}
	
	TreeSet<Employee> intList = new TreeSet<Employee>(); //dynanmic size even if we dont give size then it is fine 
	Collection<Employee> vSet = list.values();
	//Iterator<Employee> ttk =  vSet.iterator();
	
	boolean flag = false;
	for(Employee value:vSet) {
		intList.add(value);
		System.out.println("Entry "+ value);

		
	}
	
	System.out.println("Size of employee list"+intList.size());
	
}*/
	}
}
